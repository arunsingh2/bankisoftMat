package com.capgemini.takehome.servicetesting;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;
import com.capgemini.takehome.util.CollectionUtil;



public class ServiceTest {
	private static IProductService prodServiceTest;
	@BeforeClass
	public static void setUpTestEnv() {
		 prodServiceTest=new ProductService();
	}
	
	@Before
	public void setUpTestData() {
		HashMap<Integer,Product> products=new HashMap<>();
		products.put(1008, new Product("IPhone", "Electronics", "SmartPhone", 1008, 35000.0f));	
		products.put(1009, new Product("Telescope", "Toys", "PlayItem", 1009, 5000.0f));
		Product pro1= new Product("IPhone","Electronics","SmartPhone",1008,35000.0f);
		Product pro2=new Product("Telescope","Toys","PlayItem",1009,5000.0f);
	}
	
	@Test(expected=ProductCodeNotFoundException.class)
	public void testGetDetailsForInvalidProductCode() throws ProductCodeNotFoundException{
		prodServiceTest.getProductDetails(1008);
	}
	
	@Test
	public void testGetDetailsForValidProductCode() {
		Product expected= new Product("IPhone","Electronics","SmartPhone",1008,35000.0f);
		Assert.assertEquals(expected,"Product [productName=IPhone, category=Electronics, productDescription=SmartPhone, productCode=1001, productPrice=35000.0]");
	}
	
	@After
	public void tearDownData() {
		CollectionUtil.products.clear();
	}
	@AfterClass
	public static void tearDownEnv() {
		prodServiceTest=null;
	}
	
}
