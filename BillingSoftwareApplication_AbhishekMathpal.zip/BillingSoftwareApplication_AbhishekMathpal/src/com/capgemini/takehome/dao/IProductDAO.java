package com.capgemini.takehome.dao;

import com.capgemini.takehome.Exceptions.InvalidProductCodeException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
	public Product getProductDetails(int productCode);   //declaring getDetail abstract DAO method
}
