package com.capgemini.takehome.service;

import com.capgemini.takehome.Exceptions.InvalidProductCodeException;
import com.capgemini.takehome.Exceptions.InvalidQuantityException;
import com.capgemini.takehome.Exceptions.ProductCodeNotFoundException;
import com.capgemini.takehome.bean.Bill;
import com.capgemini.takehome.bean.Product;

public interface IProductService {
	//abstract declaration of methods
	public Product getProductDetails(int productCode) throws ProductCodeNotFoundException,InvalidProductCodeException;  
	public Bill getBill(int amount,Product prod) throws InvalidQuantityException;
}
